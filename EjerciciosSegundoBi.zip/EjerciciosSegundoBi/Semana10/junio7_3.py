matriz = [[1, 2, 3], [11, 12, 13]]

filas = 2
columnas = 3

for f in range(filas):
	for c in range(columnas):
		matriz[f][c] = print(matriz[f][c])	
