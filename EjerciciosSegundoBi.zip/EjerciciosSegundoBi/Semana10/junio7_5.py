promedio = 0

arreglo = [[7, 7, 8 ], [9, 8, 10], [10, 10, 3]]
estudiantes = [["Maria","Loja"], ["Luis", "Quito"], ["Jose", "Cuenca"]]

promedios = []

filas = 3
columnas = 3

for f in range(filas):
	suma = 0
	for c in range(columnas):	
		suma += arreglo[f][c]
	promedio = float(suma / 3)
	promedios =  promedio

for x in range(4):
	print(f"Nombre: %s Ciudad: %s Promedio: %d" %(estudiantes[x][0], estudiantes[x][1], promedios[x]))