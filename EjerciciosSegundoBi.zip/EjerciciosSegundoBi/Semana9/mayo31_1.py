num = 5
c = [0]
for i in range (0, num):
	print (f"posición: {i} - valor: {c}")
	print ()

