suma = 0
promedio = 0
calificacion = []

materias = (["Programación", "Base de Datos", "Contabilidad", "Biología"])

for j in materias:
	print(f"Ingrese la calificación de la materia {j}")
	calificacion.append(int(input())) 

print("-----------------------------------------------------------")

for i in calificacion:
	print(f"La nota de la materia de {i} fue {calificacion [i - 1]}")

for i in calificacion:
	suma += j

promedio = suma / i

if promedio >= 80:
	print(f"El promedio del estudiante es Sobresaliente: {promedio}")
else:
	if promedio < 80 and promedio > 60:
		print(f"El promedio del estudiante es Bueno: {promedio}")
	else:
		if promedio <= 60:
			print(f"El promedio del estudiante es Regular: {promedio}")		
				