suma = 0
promedio = 0
respuestas = []
dias = (["Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"])


for j in dias:
	print (f"Número de partidos jugados el día: {j}")
	respuestas.append(int(input()))

print ("----------------------------------------------------------------")

for i in respuestas:
	print (f"Partidos jugados el día {dias [i - 1]} fue {i}")

for i in respuestas:
	suma += i

promedio = suma / i
print(f"El promedio de partidos jugados es {promedio}")	 