sueldo = [[50, 100, 150, 30, 500, 1001],[150, 200, 50, 130, 800, 2010],[150, 20, 10, 330, 60, 601],[200, 10, 40, 70, 100, 700],[700, 101, 140, 270, 10, 60]]
dias = ["Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado"]
nombres = ["Vendedor1", "Vendedor2", "Vendedor3", "Vendedor4", "Vendedor5"]

paga = 0
tipo = 0
suma = 0

for fila in range (len(sueldo)):

    for columna in range(len(sueldo[fila])):
    	
    	if (sueldo[fila][columna] < 100):

    		valorfijo = 30
    		tipo = tipo + valorfijo

    	if (100 > sueldo[fila][columna] and sueldo[fila][columna] < 999):

    		valorfijo = 30
    		tipo = tipo + valorfijo

    	if (sueldo[fila][columna] > 100):

    		valorfijo = 30
    		tipo = tipo + valorfijo
    print ()

for fila in range (len(sueldo)):

	sueldo_semanal = 0
	paga_dueno = 0

	print(nombres[fila] + "\n" )

	for columna in range(len(sueldo[fila])):

		sueldo_diario = (sueldo[fila][columna] * 15) / 100
		print(str(dias[columna])+ " "+str(sueldo[fila][columna]))
		sueldo_semanal = sueldo_semanal + sueldo_diario
	print("\nSueldo semanal "+str(sueldo_semanal) + "\n")
	sueldo_seguro = (sueldo_semanal*14)/100
	sueldo_total = sueldo_semanal + sueldo_seguro


for fila in range (len(sueldo)):

	sueldo_semanal = 0
	paga_dueno = 0

	for columna in range(len(sueldo[fila])):
		sueldo_diario = (sueldo[fila][columna] * 15) / 100
		sueldo_semanal = sueldo_semanal + sueldo_diario
	sueldo_seguro = (sueldo_semanal*14)/100
	sueldo_total = sueldo_semanal + sueldo_seguro
	paga_dueno = paga_dueno + sueldo_total
	paga = paga + paga_dueno

pago_total = paga + tipo
print("El dueño tendrá que pagar un total de:"+ str(pago_total))