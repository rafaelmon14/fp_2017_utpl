def obtener_descuento (sueldo_neto, edad):
	d = 0
	if (edad >= 50):
		d = sueldo_neto * 0.05
	else:
		d = sueldo_neto * 0.01
	return d

nombre = ("Luis")
apellido = ("Romero")
cedula = 10203
edad = 40
sueldo_neto = 500.2
a = 5
b = 2
print(a + b)
obtener_descuento(sueldo_neto, edad) 	