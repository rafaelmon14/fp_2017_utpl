def generar_recibo (nombre, apellido, cedula, edad, sueldo_neto):
	nombre_mayuscula = obtener_mayuscula(nombre)
	descuento = obtener_descuento(sueldo_neto, edad)
	seguro = obtener_seguro(sueldo_neto)
	sueldo_final = sueldo_neto + seguro - descuento
	print(f"Recibo \n Nombre: {nombre_mayuscula} \t Apellido {apellido} \n Sueldo Final: {sueldo_final}")
	

def obtener_descuento (sueldo_neto, edad):
	d = 0
	if (edad >= 50):
		d = sueldo_neto * 0.05
	else:
		d = sueldo_neto * 0.01
	return d
	
def obtener_seguro (valor2):
	s = valor2 * 0.15
	return s

def obtener_mayuscula (nombre):
	mayus = nombre.upper()
	return mayus

nombre = ("Luis")
apellido = ("Romero")
cedula = 10203
edad = 40
sueldo_neto = 500.2

generar_recibo(nombre, apellido, cedula, edad, sueldo_neto) 