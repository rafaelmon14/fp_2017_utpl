suma = 0
filas = 3
columnas = 3

matriz = [[7, 7, 8 ], [9, 8, 10], [10, 10, 3]]

print ("Seleccione los valores a imprimir")

print ("Opción 1: Valores Diagonal")
print ("Opción 2: Valores Inferiores Diagonal")
print ("Opción 3: Valores Superiores Diagonales")
opcion = int(input())

if (opcion == 1):
	for f in range(filas):
		for c in range(columnas):
			if (f == c):
				if (matriz[f][c] % 2 != 0):
					suma += matriz[f][c]	
	print (suma)
else:
	if (opcion == 2):
		for f in range(filas):
			for c in range(columnas):
				if (f > c):
					if (matriz[f][c] % 2 != 0):
						suma += matriz[f][c]	
		print (suma)		
	else:
		if (opcion == 3):
			for f in range(filas):
				for c in range(columnas):
					if (f > c):
						if (matriz[f][c] % 2 != 0):
							suma += matriz[f][c]		
			print (suma)				