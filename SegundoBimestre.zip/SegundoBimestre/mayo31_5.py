
rangos = (["Menores a 18", "Mayores o igual a 18 y Menores o igual a 25", "Menores a 25"]) 
valores = [0]
edad = int

print ("Ingrese el número de estudiantes a evaluar: ")
contador = int(input())

for i in range (0 , contador):
	print (f"Ingrese la edad del estudiante número: {i + 1}")
	edad = int(input()) 

	if (edad < 18):
		valores[0] = valores[0] + 1
	else:
		if (edad >= 18 and edad < 25):
			valores[0] = valores[0] + 1
		else:
			valores[0] = valores[0] + 1

for i in valores:
	print(f"El número de estudiantes del rango: {rangos [i - 1]} es {i} ")
