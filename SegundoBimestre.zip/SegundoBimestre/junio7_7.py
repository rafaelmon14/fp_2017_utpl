matriz = [[7, 7, 8 ], [9, 8, 10], [10, 10, 3]]

filas = 3
columnas = 3

suma = 0
for f in range(filas):
	for c in range(columnas):
		if (f > c):
			suma += matriz[f][c]	
print (suma)	