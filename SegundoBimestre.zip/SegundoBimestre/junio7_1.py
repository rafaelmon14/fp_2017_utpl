matriz = []
filas = 4
columna = 4

for i in range (filas):
	matriz.append([0] * columna)

for f in range(filas):
	for c in range(columna):
		matriz[f][c] = print(matriz[f][c])	
	