matriz = []
filas = 4
columna = 4

for i in range (filas):
	matriz.append([0] * columna)

print (matriz)
