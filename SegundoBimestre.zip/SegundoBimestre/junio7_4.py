promedio = 0
matriz = [[7, 7, 8 ], [9, 8, 10], [10, 10, 3]]

filas = 3
columnas = 3


for f in range(filas):
	suma = 0
	for c in range(columnas):
		print(matriz[f][c])	
		suma += matriz[f][c]
	promedio = suma / 3
	print (f"Promedio: {promedio}")	
	print ()