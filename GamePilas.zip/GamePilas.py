import pilasengine
pilas = pilasengine.iniciar()
puntos = pilas.actores.Puntaje( x=200, y=200, color= pilas.colores.azul)
fondo = pilas.fondos.Fondo()
fondo.imagen = pilas.imagenes.cargar('galaxy.png')
pilas.actores.Sonido()
fin_de_Juego = False

# JUGADOR 

class MonoConControles(pilasengine.actores.mono.Mono):

    def iniciar(self):
        self.imagen = "nave1.png"
        self.y=-100

    def actualizar(self):
        if self.pilas.escena_actual().control.arriba:
            self.y += 5
        elif self.pilas.escena_actual().control.abajo:
            self.y -= 5

        if self.pilas.escena_actual().control.izquierda:
            self.x -= 5
        elif self.pilas.escena_actual().control.derecha:
            self.x += 5

mono_con_controles = MonoConControles(pilas)

# Habilidad de disparo
class MiMunicion(pilasengine.actores.Actor):

    def iniciar(self):
        self.imagen = "disparos/bola_amarilla.png"
        self.escala_y = 0.25
        self.escala_x = 0.25
        self.y = 100
    
    def actualizar(self):
        self.rotacion += 10

pilas.actores.vincular(MiMunicion) 
mono_con_controles.aprender('disparar', municion='MiMunicion', angulo_salida_disparo=90)

#EL ENEMIGO
class PiedraEnemiga(pilasengine.actores.Piedra):

    def iniciar(self):
        self.imagen = "piedra_media.png"
        self.aprender( pilas.habilidades.PuedeExplotar )
        self.x = pilas.azar(-300, 300)
        self.y = 290
        self.velocidad = pilas.azar(5, 15) / 5.0

    def actualizar(self):
        self.rotacion += 2
        self.y -= self.velocidad

        # Elimina el objeto cuando sale de la pantalla.
        if self.y < -300:
            self.eliminar()
            puntos.reducir(25)
            
enemigos = pilas.actores.Grupo()
def crear_enemigo():
    actor = PiedraEnemiga(pilas)
    enemigos.agregar(actor)

pilas.tareas.siempre(0.5, crear_enemigo)

def eliminar_enemigo(disparo, enemigo):
    enemigo.eliminar()
    disparo.eliminar()
    puntos.aumentar(50)

def perder(nav, ene):
	#global fin_de_Juego
	
	nav.eliminar()
	pilas.tareas.eliminar_todas()
	fin_de_Juego = True

	pilas.avisar("GAME OVER")

mono_con_controles.aprender(pilas.habilidades.LimitadoABordesDePantalla)

pilas.colisiones.agregar(mono_con_controles, enemigos, perder)
pilas.colisiones.agregar("MiMunicion", "PiedraEnemiga", eliminar_enemigo)

pilas.ejecutar()